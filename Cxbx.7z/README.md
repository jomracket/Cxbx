# Cxbx-Reloaded - An Xbox Emulator

Cxbx-Reloaded is an emulator for running Microsoft Xbox (and eventually, Chihiro) games on Microsoft Windows.

The project began life as a fork of Cxbx with added 64-bit support. Work is currently underway to backport some of the improvements from Dxbx.

Cxbx-Reloaded is still pretty unstable, don't expect it to run much at this point.

## System Requirements
  * Windows 10 64-bit (May work on other versions, but this has not been tested).
  * A graphics card that supports Direct3D 8.

## Screenshot Gallery
http://imgur.com/a/Bzvti
The screenshot gallery is regularly updated

## Special Thanks
All contributers to the original Cxbx and Dxbx projects, without which Cxbx-Reloaded would not exist at all


compiled by EmuCR